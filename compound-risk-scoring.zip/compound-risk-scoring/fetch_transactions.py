import requests
import pandas as pd
import time

# To Load wallets
with open("wallets.txt") as f:
    wallets = [line.strip().lower() for line in f if line.strip()]

# Use public Compound V2 Graph endpoint (Goldsky)
url = "https://api.goldsky.com/api/public/project_cl9c4nyzy0k1s01xj0w1ygk4a/subgraphs/compound-v2-mainnet/stable/gn"

query_template = """
query GetAccount($id: ID!) {
  account(id: $id) {
    id
    tokens {
      symbol
      lifetimeSupply
      lifetimeBorrow
      lifetimeRepay
      lifetimeRedeem
      market {
        id
      }
    }
  }
}
"""

all_data = []

for wallet in wallets:
    try:
        res = requests.post(url, json={"query": query_template, "variables": {"id": wallet}})
        data = res.json()
        if 'data' in data and data['data']['account'] and data['data']['account']['tokens']:
            for token in data['data']['account']['tokens']:
                row = {
                    "wallet": wallet,
                    "symbol": token.get("symbol", "N/A"),
                    "lifetimeSupply": float(token.get("lifetimeSupply", 0)),
                    "lifetimeBorrow": float(token.get("lifetimeBorrow", 0)),
                    "lifetimeRepay": float(token.get("lifetimeRepay", 0)),
                    "lifetimeRedeem": float(token.get("lifetimeRedeem", 0)),
                    "market": token.get("market", {}).get("id", "N/A")
                }
                all_data.append(row)
        time.sleep(0.5)  # The endpoint
    except Exception as e:
        print(f"Error with wallet {wallet}: {e}")

# Saves result
df = pd.DataFrame(all_data)
df.to_csv("transactions.csv", index=False)
print("✅ transactions.csv generated with", len(df), "rows.")
