import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load features
df = pd.read_csv("wallet_features.csv")

# Scoring function
def score(row):
    score = 0

    # Repayment behavior — key indicator
    if row["repay_borrow_ratio"] > 0.9:
        score += 400
    elif row["repay_borrow_ratio"] > 0.5:
        score += 300
    elif row["repay_borrow_ratio"] > 0.2:
        score += 200
    else:
        score += 100

    # Redeem/supply ratio
    if row["redeem_supply_ratio"] < 0.5:
        score += 150
    else:
        score += 50

    # Supply volume bonus
    if row["supply"] > 3000:
        score += 150
    elif row["supply"] > 1000:
        score += 100
    else:
        score += 50

    # Diversity of tokens
    score += row["unique_tokens"] * 50

    return min(score, 1000)

# Apply scoring
df["score"] = df.apply(score, axis=1)

# Save to CSV
df[["wallet", "score"]].to_csv("wallet_scores.csv", index=False)

# Save score distribution plot
plt.figure(figsize=(8, 5))
sns.histplot(df["score"], bins=10, kde=True)
plt.title("Wallet Risk Score Distribution")
plt.xlabel("Score")
plt.ylabel("Number of Wallets")
plt.savefig("score_distribution.png")

print("✅ wallet_scores.csv and score_distribution.png generated.")
