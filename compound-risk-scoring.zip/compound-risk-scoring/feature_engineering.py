import pandas as pd

# Load the transaction data
df = pd.read_csv("transactions.csv")

# Group by wallet and compute basic stats
wallet_stats = []

for wallet, group in df.groupby("wallet"):
    supply_amt = group[group["action"] == "supply"]["amount"].sum()
    borrow_amt = group[group["action"] == "borrow"]["amount"].sum()
    repay_amt = group[group["action"] == "repay"]["amount"].sum()
    redeem_amt = group[group["action"] == "redeem"]["amount"].sum()
    
    unique_tokens = group["token"].nunique()
    
    # Calculate ratios
    repay_borrow_ratio = repay_amt / borrow_amt if borrow_amt > 0 else 0
    redeem_supply_ratio = redeem_amt / supply_amt if supply_amt > 0 else 0
    
    wallet_stats.append({
        "wallet": wallet,
        "supply": supply_amt,
        "borrow": borrow_amt,
        "repay": repay_amt,
        "redeem": redeem_amt,
        "repay_borrow_ratio": repay_borrow_ratio,
        "redeem_supply_ratio": redeem_supply_ratio,
        "unique_tokens": unique_tokens
    })

# Save features to CSV
features_df = pd.DataFrame(wallet_stats)
features_df.to_csv("wallet_features.csv", index=False)

print("✅ wallet_features.csv generated.")
