
---
## 📈 `analysis.md`

Create a new file called `analysis.md` with the following content:

```markdown
# Score Analysis

This analysis reflects the behavior of wallets across different score ranges (0–1000). The goal is to understand wallet quality in each band and what actions contribute to their score.

---

## 📊 Score Distribution Summary

| Score Range | # Wallets | Observed Behavior Summary |
|-------------|-----------|----------------------------|
| 0–100       | 0         | Not present                |
| 100–200     | 0         | Not present                |
| 200–300     | 1         | Poor repay ratio, low activity |
| 300–400     | 1         | Moderate repay, few tokens |
| 400–500     | 0         | Not present                |
| 500–600     | 1         | Decent supply, repay ratio improving |
| 600–700     | 0         | Not present                |
| 700–800     | 0         | Not present                |
| 800–900     | 0         | Not present                |
| 900–1000    | 0         | Not present                |

---

## 🔎 Behavior by Score Range

- **300–400:**  
  - Wallets made limited or imbalanced transactions.
  - Repay/Borrow ratios were low.
  - Token usage was narrow.

- **500–600:**  
  - Wallets showed decent engagement.
  - Supplied and repaid a good portion.
  - Token diversity played a positive role.

---

## 🧠 Insights

- The **repay-to-borrow ratio** had the strongest impact on scoring.
- **Token diversity** boosts scores significantly.
- Wallets with single action patterns (e.g., only borrowing) scored much lower.
